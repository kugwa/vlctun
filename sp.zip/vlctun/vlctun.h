#define MTU 1500

int tun_attach(char*);
int tx_init(char*,int);
int rx_init(int);
