#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <linux/if.h>
#include "vlctun.h"

int main(int argc,char **argv)
{
	char name[IFNAMSIZ]; //name of the tun device
	int fd; //use this fd to access the tun device
	
	if(argc!=3){
		puts("Usage: rx PHYS_DEV LOCAL_PORT");
		return -1;
	}
	
	//attach to the given tun device
	strncpy(name,argv[1],IFNAMSIZ);
	if((fd=tun_attach(name))<0 || strcmp(name,argv[1])){
		fprintf(stderr,"main(): failed to attach to %s\n",argv[1]);
		return -1;
	}
	
	//initializing the rx part of vlc
	int rxfd;
	if((rxfd=rx_init(atoi(argv[2])))<0){
		fprintf(stderr,"main(): failed to initialize the rx\n");
		return -1;
	}
	
	//receive packets from the rx and then write them to the tun device
	int nrecv;
	char pkt[MTU];
	while((nrecv=read(rxfd,pkt,MTU))>0){
		fprintf(stderr,"main(): %d bytes received\n",nrecv);
		write(fd,pkt,nrecv);
	}
	
	//cleanup
	close(rxfd);
	close(fd);
	return 0;
}
