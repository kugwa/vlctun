#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <linux/if.h>
#include "vlctun.h"

int main(int argc,char **argv)
{
	char name[IFNAMSIZ]; //name of the tun device
	int fd; //use this fd to access the tun device
	
	if(argc!=4){
		puts("Usage: tx PHYS_DEV REMOTE_ADDR REMOTE_PORT");
		return -1;
	}
	
	//attach to the given tun device
	strncpy(name,argv[1],IFNAMSIZ);
	if((fd=tun_attach(name))<0 || strcmp(name,argv[1])){
		fprintf(stderr,"main(): failed to attach to %s\n",argv[1]);
		return -1;
	}
	
	//initializing the tx part of vlc
	int txfd;
	if((txfd=tx_init(argv[2],atoi(argv[3])))<0){
		fprintf(stderr,"main(): failed to initialize the tx\n");
		return -1;
	}
	
	//read packets from the tun device and then send them out by the tx
	int nread;
	char pkt[MTU];
	while((nread=read(fd,pkt,MTU))>0){
		write(txfd,pkt,nread);
		fprintf(stderr,"main(): %d bytes sent\n",nread);
	}
	
	//cleanup
	close(txfd);
	close(fd);
	return 0;
}
