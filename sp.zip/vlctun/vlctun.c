#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <linux/if.h>
#include <linux/if_tun.h>

int tun_attach(char *dev)
{
	struct ifreq ifr;
	int fd,err;
	
	if((fd=open("/dev/net/tun",O_RDWR))<0){
		fprintf(stderr,"tun_attach(): failed to open the clone device\n");
		return fd;
	}
	
	memset(&ifr,0,sizeof(ifr));
	ifr.ifr_flags=IFF_TUN;
	if(dev[0])strncpy(ifr.ifr_name,dev,IFNAMSIZ);
	
	if((err=ioctl(fd,TUNSETIFF,(void*)&ifr))<0){
		fprintf(stderr,"tun_attach(): failed to attach to %s\n",dev);
		close(fd);
		return err;
	}
	strcpy(dev,ifr.ifr_name);
	return fd;
}

int tx_init(char *ipstr,int port)
{
	int sfd;
	struct sockaddr_in sa;
	
	if((sfd=socket(AF_INET,SOCK_STREAM,0))<0)return -1;
	memset(&sa,0,sizeof(sa));
	sa.sin_family=AF_INET;
	inet_pton(AF_INET,ipstr,&sa.sin_addr);
	sa.sin_port=htons(port);
	
	if(connect(sfd,(struct sockaddr*)&sa,sizeof(sa))<0)return -1;
	return sfd;
}

int rx_init(int port)
{
	int lfd,sfd,clen;
	struct sockaddr_in sa,ca;
	
	if((lfd=socket(AF_INET,SOCK_STREAM,0))<0)return -1;
	memset(&sa,0,sizeof(sa));
	sa.sin_family=AF_INET;
	sa.sin_addr.s_addr=INADDR_ANY;
	sa.sin_port=htons(port);
	if(bind(lfd,(struct sockaddr*)&sa,sizeof(sa))<0)return -1;
	listen(lfd,5);
	
	clen=sizeof(ca);
	sfd=accept(lfd,(struct sockaddr*)&ca,&clen);
	return sfd;
}
